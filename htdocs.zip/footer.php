<link rel="stylesheet" href="style.css">


<footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="/" class="footer-logo">
                    </a>
                    <p class="footer-description">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                    Nisl tincidunt eget nullam non. Quis hendrerit dolor magna eget est lorem ipsum dolor sit. 
                    Volutpat odio facilisis mauris sit amet massa. 
                    Commodo odio aenean sed adipiscing diam donec adipiscing tristique. 
                    Mi eget mauris pharetra et
                    </p>
                </div>
                
                <div class="footer-links">
                    <h4>Hizmetler</h4>
                    <a href="/instagram">Instagram</a>
                    <a href="/tiktok">TikTok</a>
                    <a href="/twitter">Twitter</a>
                    <a href="/youtube">YouTube</a>
                </div>
                
                <div class="footer-links">
                    <h4>Şirket</h4>
                    <a href="/hakkimizda">Hakkımızda</a>
                    <a href="/blog">Blog</a>
                    <a href="/iletisim">İletişim</a>
                </div>
                
                <div class="footer-links">
                    <h4>Destek</h4>
                    <a href="/sss">Sık Sorulan Sorular</a>
                    <a href="/kullanim-kosullari">Kullanım Koşulları</a>
                    <a href="/gizlilik-politikasi">Gizlilik Politikası</a>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; 2024 Emre. Tüm hakları saklıdır.</p>
            </div>
        </div>
    </footer>
