<link rel="stylesheet" href="style.css">

<header class="header">
        <nav class="nav container">
            <a href="/" class="logo">
                <span class="logo-text">Emre</span>
            </a>
            <div class="nav-menu">
                <a href="#hizmetler">Hizmetler</a>
                <a href="#paketler">Paketler</a>
                <a href="#hakkimizda">Hakkımızda</a>
                <a href="#iletisim">İletişim</a>
            </div>
            <div class="nav-buttons">
                <a href="/giris" class="btn btn-outline">Giriş Yap</a>
                <a href="/kayit" class="btn btn-primary">Kayıt Ol</a>
            </div>
        </nav>
    </header>